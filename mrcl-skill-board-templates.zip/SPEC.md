# Award Board System v2 — Engine Build Spec

8 base layouts × 3 content variants = **24 files** in `v2/`.

Read this document with `IMAGERY.md`. This one governs **structure and copy**;
that one governs **every image the engine sources or generates**. A board that
follows this spec but ignores `IMAGERY.md` will still look like a draft.

---

## PART 1 — THE CONTRACT

| Property | Value |
|---|---|
| Canvas | exactly `1920 × 1080`, `#board`, `overflow:hidden` |
| Scaling | one script per file: `scaleBoard()` on `load` + `resize` |
| Motion | none — no animation, transition, keyframe, `:hover`, `:focus`, scroll |
| Layout | CSS Grid / Flexbox only; no absolute positioning except `#board` itself |
| Colour | seven `:root` variables; no hard-coded hex outside `:root` |
| Type | two `:root` variables + one Google Fonts `<link>` |
| Verified | all 24 files measure exactly 1080 × 1920 with zero clipped elements |

Headless capture: viewport `1920 × 1080` → `scale(1)` → 1:1 PNG. Wait for
`document.fonts.ready` **and** all `<img>` `decode()` before capture.

### The seven variables

```css
--font-headline   --font-body
--color-primary   /* solid panel / band colour */
--color-accent    /* labels, metric units, rules */
--color-bg        /* board ground */
--color-text      /* body + headline */
--color-muted     /* secondary text */
```

Re-theming a board to a client palette means editing these seven values and
nothing else. Never introduce an eighth colour.

### Universal slot selectors

| Slot | Selector | How to fill |
|---|---|---|
| Hero | `.hero` (08 has `.hero-a` + `.hero-b`) | `style="background-image:url(…)"` |
| Headline | `.headline` | text, 2–6 words |
| Subline | `.subline` | text, 8–14 words, **sentence case** |
| Copy block | `.zone` → `.lbl` + `p` | label + body copy |
| Metric | `.met` → `.m-n` + `.m-u` | figure + unit. **Unknown → delete the `.met`.** Never `TBC` / `N/A` / `—` / `0` |
| Press logo | `.wall` → `img.pressmark` | `src` = real lockup, ink baked in |
| Press name | `.wall` → `span.pressmark-text` | text fallback, mixable |
| Pull quote | `.quote` → `p` + `img` (04 only) | quote + outlet lockup |
| Tile | `.tile` | `style="--tile-img:url(…)"` — **never** `background-image`; every tile is 16:9 |
| Brand | `img.brandmark` | `src` = real lockup. **Must be an `<img>`** — a text wordmark in its place is a fail |

```html
<div class="hero" style="background-image:url('data:image/jpeg;base64,…')">
<div class="tile" style="--tile-img:url('data:image/jpeg;base64,…')">
<img class="brandmark" src="data:image/svg+xml;base64,…" alt="Brand Name">
<img class="pressmark" src="data:image/svg+xml;base64,…" alt="Publication Name">
<span class="pressmark-text">Publication Name</span>
```

`.tile` composites its own bottom scrim over `--tile-img`. Writing
`background-image` on a `.tile` destroys the scrim and the caption becomes
illegible. This is the single most common injection error.

**Logo colour is baked into the asset, not applied by CSS.** An SVG referenced
through `<img src>` renders in an isolated document and cannot inherit the host's
`color`, so `fill="currentColor"` resolves to black on every board. `assets/logos/`
ships two complete sets and each board references the right one:

| Board | Logo set |
|---|---|
| 01, 04, 05, 06, 08 (dark) | `press-NN-rev.svg`, `brand-mark-rev.svg` — light ink `#f4f2ec` |
| 02, 03, 07 (light) | `press-NN.svg`, `brand-mark.svg` — dark ink `#14140f` |

Real logos must follow the same rule — see `IMAGERY.md` Part 6.

### Variant law

Every board carries a `data-variant` attribute on `#board` (`lean` · `base` · `loaded`) so injection logic can detect the active tile zone without
parsing CSS.

| | Metrics | Press | Execution zone | Copy blocks |
|---|---|---|---|---|
| `--lean` | 3 | 8 | 3-slot tile strip | 3, one line each |
| base | 4 | 16 | 5-slot tile strip | 3 at 40 / 50 / 40 words |
| `--loaded` | 6 | 24 | 8-slot tile strip | 5 at full length |

### Execution-zone selection

Select on **usable execution assets**, then write copy to fit.

| Usable execution assets | Variant | Execution zone |
|---|---|---|
| 0–1 | base or `--lean` with `.strip` **removed** | none — the grid reflows, verified on all 8 boards |
| **2–3** | `--lean` | tile strip, 2 or 3 slots |
| 4–5 | base | tile strip, 4 or 5 slots |
| 6+ | `--loaded` | tile strip, 7 or 8 slots |

**Two is the minimum.** A single execution image is not enough to justify the zone —
one slot in a strip built for several reads as a gap, and blowing one asset up to
fill the space invites the scrutiny a hero gets. With 0 or 1 usable assets, **remove
`.strip` entirely**; every board's grid reflows cleanly with no dead band.

**Strips are count-tolerant.** Each strip is `display:flex; justify-content:center`
with a fixed slot height, so it centres whatever count it is given — no empty
columns. The 3-slot lean design holds 2 without adjustment, base holds 4 or 5, and
loaded holds 7 or 8. Delete the surplus `.tile` elements; change nothing else.

The metric and press counts still gate independently: fewer than 3 metrics or
fewer than 6 press logos forces `--lean` regardless of execution assets.

### Execution slots are 16:9 — all of them

Every execution slot on every board and every variant is **exactly 16:9**, set with
`aspect-ratio` so the slot derives its height from its column width. This is the
v3 fix: the earlier strips were 3:1, so a
landscape interface asset injected via `background-size:cover` lost 70–80% of its
height. Nothing crops now beyond the natural 16:9 frame.

| Variant | Slot size | Slots | Behaviour at one fewer |
|---|---|---|---|
| `--lean` | 425 × 239 | 3 | centres at 2 — the 3-slot design holds both counts |
| base | 380 × 214 | 5 | centres at 4 |
| `--loaded` | 236 × 133 | 8 | centres at 7 |

**Legibility floor.** A tile carrying a screen, UI, poster, artefact or newspaper
must render at **≥ 300px wide**. Below that the execution is unreadable and the
tile is decoration. Consequence: `--loaded` (236px) and board 04 (126px) are for
**environmental** execution shots — an OOH site, a crowd, a retail moment — never
for interfaces. If the campaign's executions are screens, use `--lean` (425px) or
base (380px) with fewer, larger tiles, or board 07, whose grid cells reach 423px.

**Empty flanks.** At 2–3 slots the strip centres inside a 1280px zone rather than
floating in 1920 — the wide empty flanks on the reviewed Knorr, Dove and Foodpanda
boards read as missing content. The zone shrinks with the count; it does not
leave the slots adrift.

Boards that deviate, and why:

| Board | Deviation |
|---|---|
| 04 | strip sits inline beside the brand, so its slots are the smallest in the system: 126 × 71 (base), 139 × 78 (lean), 137 × 77 (loaded) |
| 07 | grid board — the strip runs inside its own 1832px gutter: 423 × 238 (base), 601 × 338 (lean), 300 × 169 (loaded); two further assets sit in the grid itself |

Measured boxes for every board and variant are in `templates.json`.

**Consequence for asset prep:** supply execution assets at 16:9. A portrait or
square asset still crops — but now it crops to a normal frame, not a letterbox
sliver. Full rules in `IMAGERY.md`.

---

## PART 2 — THE EIGHT BOARDS

All coordinates are **measured from the rendered base variant** as
`x, y, w, h` in board pixels. Lean and loaded shift the foot bands but never the
hero geometry or the headline box.

---

### 01 · Centred Monument — `v2/01-centred-monument.html`

**Dark** `#0c0c0c` / accent `#d8b269` · Archivo 900 + Archivo Narrow
**Full bleed · centred lockup · the workhorse.**

Use it when the campaign has **one commanding image** and the idea can be said in
six words. If you are unsure which board to pick and the hero is strong, pick this.

| Slot | Box | Type |
|---|---|---|
| Hero | `0, 0, 1920, 1080` | full bleed |
| Brand | `48, 38`, h 52 | logo |
| Press wall | `692, 38, 1180, 58` | logos h 22, right-aligned, wraps |
| Headline | `127, 292, 1667, 135` | 150px / 900 / uppercase, centred |
| Subline | `625, 447, 670, 38` | 31px / 500, centred |
| Copy blocks | first at `48, 681, 300, 120` | 300px columns, spaced across |
| Metric row | `48, 848, —, 78` | 64px figures, above a hairline |
| Tile strip | `0, 952, 1920, 128` | full bleed, 5 × 382 |

**Where type falls on the image:** brand and wall at `y 38–96`; the centred
lockup between `y 292–485`; copy and metrics from `y 681` down. The picture reads
cleanly in two windows — `y 100–280` and `y 490–660`. Put the subject there.

The veil darkens the top 26% and bottom 22%. A hero whose subject sits at the very
top or very bottom of frame will be swallowed.

**Fails when:** the headline runs past 6 words (it wraps to 3 lines and collides
with the subline); the hero has fine detail behind the centred lockup; the hero is
a flat colour field with no depth, which makes the veil look like a mistake.

---

### 02 · Hero Object — `v2/02-hero-object.html`

**Light** `#f4f2ec` / accent `#a8420f` · Bodoni Moda + Archivo
**Full bleed, no scrim · object at centre · copy in the margins.**

The only board with **no veil of any kind**. Everything depends on the hero having
its own clean ground. Use it for product, packaging, an artefact, a physical object.

| Slot | Box | Type |
|---|---|---|
| Hero | `0, 0, 1920, 1080` | full bleed, **unscrimmed** |
| Brand | `52, 40`, h 52 | logo, top left |
| Headline | `556, 40, 808, 88` | 88px / 700 serif, centred |
| Subline | `640, 140, 640, 30` | 23px, centred, muted |
| Metrics | `1660, 68, 208` | column, ranged right, 40px |
| Copy left | `52, 354, 340` | 340px flank |
| Copy right | `1528, 354, 340` | 340px flank |
| Press wall | `0, 865, 1920, 95` | centred, on a hairline |
| Tile strip | `0, 960, 1920, 120` | full bleed |

**Clear zone the hero must provide:** `x 420–1500`, `y 200–840`. The object lives
there. Everything outside it carries type directly on the image with no protection.

**Fails when:** the hero has any busy or dark region under the flanking copy —
there is no scrim to save it. If the only available image is busy, use **01**
instead. Do not add a scrim to this board; the light register is the point.

---

### 03 · Device Frame — `v2/03-device-frame.html`

**White** `#ffffff` / accent `#1f5fd0` · Space Grotesk + IBM Plex Mono
**Full bleed · centred device · callouts radiating.**

For anything where **what the thing does** must be shown: an app, a platform, a
tool, an AI product, a piece of software.

| Slot | Box | Type |
|---|---|---|
| Hero | `0, 0, 1920, 1080` | full bleed, unscrimmed |
| Brand | `52, 34`, h 52 | logo |
| Press wall | `628, 36, 1240, 48` | logos h 19, right, on a hairline rule |
| Headline | `52, 131, 880, 76` | 78px / 700, ranged left |
| Subline | `988, 179, 880, 28` | 21px, **beside** the headline, muted |
| Copy blocks | `52, 235, 318` | left column |
| Metrics | `1550, 268, 318` | right column, 46px |
| Tile strip | `0, 948, 1920, 132` | full bleed |

**Clear zone the hero must provide:** `x 400–1520`, `y 230–930` — a
`1120 × 700` window for the device or UI. Ground must be pale; this is a white
board and the hero is not scrimmed.

`--loaded` splits five copy blocks across both flanks and sets the metrics 2-up at
34px. Geometry of the centre window is unchanged.

**Fails when:** the device is shot on a dark or saturated ground (it reads as a
hole in the board); the UI is too small to read at 1:1; there are more than 5
callouts.

---

### 04 · The Logo Wall — `v2/04-logo-wall.html`

**Navy** `#07101d` / accent `#e08a4d` · Archivo 900
**Banded, not full bleed · press leads · quotes flank the headline.**

The only banded board in v2, and the only one where **earned coverage is the
argument**. PR, news-making, stunts, anything where the answer to "did it work" is
"look who covered it".

| Slot | Box | Type |
|---|---|---|
| Press wall | `52, 26, 1816, 60` | up to 24 logos h 23, **centred** |
| Pull quote L | `52, 116, 340` | 19px italic + outlet lockup h 19 |
| Headline | `382, 116, 1155, 96` | 104px / 900 / uppercase, centred |
| Subline | `382, 224, 1155, 30` | 24px, centred |
| Pull quote R | `1528, 116, 340` | right-aligned |
| Hero | `0, 284, 1920, 626` | **band**, not full bleed |
| Metric row | `52, 800, —, 80` | 66px, reversed on the hero foot |
| Copy blocks | `52, 954, 283` | zone bar below the hero |
| Brand + tiles | brand h 46 at `1020, 983`; strip `1268, 958, 600, 96` | foot right |

**Hero requirement:** landscape, subject mid-frame. Only `626px` of height, so a
tall subject will be cropped hard. The bottom `110px` carries the metric row.

**Fails when:** there are fewer than 10 real press logos — the wall is the board's
entire top third and a sparse one reads as a failure. Under 10 logos, use `--lean`
(8) or pick a different board. Two genuine pull quotes are mandatory; one quote
plus an empty slot looks broken.

---

### 05 · The Left Rail — `v2/05-left-rail.html`

**Dark** `#0c0c0c` / accent `#d8b269` · Archivo
**Full bleed · everything ranged left · picture holds the right.**

The **densest** board. Use it when there is a lot to explain and the image can
afford to give up its left third.

| Slot | Box | Type |
|---|---|---|
| Hero | `0, 0, 1920, 1080` | full bleed |
| Brand | `48, 38`, h 52 | logo |
| Press wall | `912, 38, 960, 90` | right-aligned, wraps to 2–3 rows |
| Headline | `48, 158, 604, 187` | 104px / 900 / uppercase, 2–3 lines |
| Subline | `48, 367, 604, 31` | 24px |
| Copy blocks | `48, 420, 604` | stacked in the rail |
| Metric row | `48, 848, —, 76` | 62px |
| Tile strip | `0, 950, 1920, 130` | full bleed |

**Hero requirement:** visual weight **right of centre**. The left `700px` is
veiled to near-black; anything important there is lost. A hero that is
symmetrical or left-weighted is the wrong choice for this board.

**Fails when:** the headline exceeds 3 lines at 104px (it pushes into the copy);
the hero's right half is empty, leaving a large dead area beside a dense rail.

---

### 06 · The Figure Board — `v2/06-figure-board.html`

**Dark** `#0c0c0c` / accent `#d8b269` · Instrument Serif + Archivo
**Full bleed · a person at centre · copy in two flanks.**

For work carried by **a human subject**: cause, activism, healthcare, portraiture,
testimony.

| Slot | Box | Type |
|---|---|---|
| Hero | `0, 0, 1920, 1080` | full bleed, radial + linear veil |
| Brand | `52, 36`, h 52 | logo |
| Press wall | `628, 36, 1240, 56` | right-aligned |
| Headline | `80, 114, 1760, 111` | 118px serif / uppercase, centred, crosses the frame |
| Subline | `460, 239, 1000, 33` | 26px, centred |
| Copy left | `52, 306, 346` | flank |
| Copy right | `1522, 306, 346` | flank |
| Metric row | `52, 858, —, 72` | 60px |
| Tile strip | `0, 956, 1920, 124` | full bleed |

**Hero requirement:** a single figure, **full height, centred**, occupying roughly
`x 442–1478` — a `1036px` window. The radial veil keeps that centre clear and
darkens the edges, so the flanking copy sits on shadow. Head should clear the
headline, i.e. below `y 240`.

**Fails when:** the subject is a group (the radial veil cuts the outer figures);
the subject is cropped at the waist (the board is built for full height); the
figure is off-centre.

---

### 07 · The Evidence Grid — `v2/07-evidence-grid.html`

**Light** `#f4f2ec` / accent `#a8420f` · Newsreader + Archivo
**Grid-led · the hero is one cell · the system is the proof.**

The only board where the image does **not** dominate. Use it when the campaign
produced *many* artefacts — a design system, a platform, a toolkit, a long-running
programme — and breadth is the argument.

| Slot | Box | Type |
|---|---|---|
| Brand | `44, 40`, h 52 | logo |
| Headline | `44, 104, 472, 140` | 70px / 600 serif, ranged left |
| Subline | `44, 256, 472, 53` | 20px, muted |
| Copy blocks | `564, 40, 255` each | 3 columns beside the headline |
| Metrics | `1437, 70, 204` | ranged right, 40px, 2-up |
| Hero | `44, 331, 1067, 457` | largest cell, 7 of 12 columns |
| Feature tile | `1116, 331, 760, 226` | large cell beside the hero |
| Tile strip | `44, 810, 1832, 150` | remaining tiles |
| Press wall | `44, 1002, 1400, 52` | foot, muted logos h 20 |

Every cell has a `1px` hairline border. This is the only board where tiles are
bordered rather than bled.

**Fails when:** fewer than 5 real artefacts (the grid goes hollow — use another
board); the artefacts are all the same shape and colour, which makes the grid read
as a texture instead of evidence.

---

### 08 · The Sequence — `v2/08-sequence.html`

**Navy** `#07101d` / accent `#e08a4d` · Space Grotesk
**Full bleed × 2 · split down the middle · read left to right.**

The only **two-hero** board. Use it for before/after, phase one/phase two, or any
mechanic that only makes sense as a progression.

| Slot | Box | Type |
|---|---|---|
| Hero A | `0, 0, 960, 1080` | left half — *before* / *phase 1* |
| Hero B | `960, 0, 960, 1080` | right half — *after* / *phase 2*, 1px rule between |
| Brand | `52, 36`, h 52 | logo |
| Press wall | `808, 36, 1060, 90` | right-aligned |
| Headline | `100, 144, 1720, 90` | 96px / 700 / uppercase, centred across both |
| Subline | `430, 246, 1060, 31` | 24px, centred |
| Stage labels | `52` and `1012`, `y ~640` | `01` / `02` at 34px accent + caption |
| Copy blocks | `52, 722, 579` | banded across the foot |
| Metric row | `52, 865, —, 74` | 60px, above a hairline |
| Tile strip | `0, 962, 1920, 118` | full bleed |

Stage captions default to `Before` / `After`. Rename freely — `Day 1` / `Day 90`,
`Prototype` / `Rollout`, `Before us` / `After us`.

**Hero requirement:** two images with **comparable framing, focal length and
crop** — the comparison is the whole point. Two unrelated compositions read as a
mistake rather than a sequence.

**Fails when:** the two heroes have different colour temperature or exposure (it
looks like a printing error, not a change); either hero is landscape-wide and gets
cropped to 960 (shoot or generate at 4:5 per side).

---

## PART 3 — SELECTION

Pick from **the campaign's strongest asset**, not from the category.

| Strongest asset | Board |
|---|---|
| One commanding environment or film frame | **01** Centred Monument |
| A product, pack, or physical artefact | **02** Hero Object |
| A screen, app, device, AI demo | **03** Device Frame |
| Earned coverage (10+ real logos) | **04** The Logo Wall |
| A strong image *and* a dense argument | **05** The Left Rail |
| One human subject, full height | **06** The Figure Board |
| Many artefacts; breadth is the story | **07** The Evidence Grid |
| A before/after or phased mechanic | **08** The Sequence |

Tie-breakers:

- **Dark boards** (01, 04, 05, 06, 08) need a hero with tonal range and shadow.
- **Light boards** (02, 03, 07) need a pale, clean-ground hero.
- 05 needs weight **right**; 02, 03, 06 need weight **centred**; 01 needs weight
  **mid-frame**.
- Producing two boards for one campaign: pair an image-led board (01, 02, 05, 06)
  with a structure-led one (03, 04, 07, 08). Never two image-led boards.

---

## PART 4 — QA GATE

Run every check. Any failure blocks the board.

**Geometry**
1. `#board.scrollHeight === 1080` and `scrollWidth === 1920`.
2. No descendant of `#board` extends past its box. **Test every descendant, not
   just `#board`** — a reviewed board shipped with its metric column sliced by the
   right edge (`41%` reading as `4|1%`) because only the board box was measured.
2a. **Dead-space gate.** Walk the board in 60px horizontal bands; every band must
   contain at least one painted element other than the board background. No empty
   band taller than 120px, and the lowest painted element's bottom must be within
   60px of `y 1080`. Two reviewed boards were ~40% bare below the fold.
2b. **Collision gate.** For every text element, `document.elementFromPoint` at its
   centre must return that element or a descendant. A reviewed subline sat inside
   the board box but behind the hero device — bounds checks do not catch overlap.
3. Headline over budget is the usual cause — cut words first; reduce
   `.headline` font-size in 8px steps only as a last resort. Never resize the box.
4. Metric strings ≤ 7 characters (`+312%`, `1.2BN`, `$4.8M`). Metric rows are
   `minmax(0,1fr)` so they cannot widen the board, but they can clip.

**Content**
5. Zero occurrences of: `[NUMBER]`, `[UNIT]`, `Publication`, `Brand Name`,
   `Campaign Headline`, `Shorter Line`, `Forty words`, `Fifty words`,
   `One sentence-case line`, `One line explaining`.
5a. Zero occurrences of `TBC`, `N/A`, `—`, `Pending` or a bare `0` in any `.m-n`.
   Unknown metrics are **deleted**, not labelled. Fewer than 2 remaining → remove
   the metric row.
5b. **Truncation gate.** Every `.zone p` ends in terminal punctuation (`.`, `?`,
   `!`). Copy that ends mid-phrase was clipped by its box instead of being trimmed
   at a sentence boundary before injection.
6. `.subline` populated on every board, sentence case, 8–14 words.
7. Copy blocks within budget (40 / 50 / 40, +40 / 40 on loaded).
8. Variant matches assets: no `--loaded` under 6 tiles, no base under 4 metrics,
   no `--loaded` under 20 press logos.
9. Unfilled slots **removed from the DOM** — never rendered empty or as `—`.

**Images**
10. Every `.hero` has a real `url()`. On 08, **both** `.hero-a` and `.hero-b`.
11. Every `.tile` has a real `--tile-img` and no `background-image` override.
11a. **No placeholder gradients.** Sample each tile's rendered pixels: standard
    deviation of luminance below `0.06`, or fewer than 12 distinct quantised
    colours, means a flat or two-stop field, not a photograph → **hard fail**. This
    was the defining flaw of the first engine build.
11b. Each `.tile` contains **exactly one** `.tile-cap`. A reviewed board rendered
    every caption twice.
11c. Tile captions name a real deliverable (`IN-APP TRACKER`, `EARNED MEDIA`,
    `POLICY PILOT`) rather than only a generic channel where the specific is known.
11d. Any tile carrying a screen, UI, poster or artefact renders ≥ 300px wide.
12. The strip holds **at least 2** slots, or is removed entirely. Never 1.
12a. Every execution slot measures 16:9 (± 0.04). If a slot is not 16:9 the
    `aspect-ratio` rule has been overridden — restore it rather than resizing.
12b. **Collision test, not just a bounds test:** for every text element, assert
    `document.elementFromPoint` at its centre returns that element or a descendant.
    An element can sit inside the board box and still be painted over — a bounds
    check will not catch it.
13. No `assets/*.jpg` or `assets/logos/*.svg` path survives in output.
14. All `IMAGERY.md` gates passed (resolution, aspect, clear-zone, artefact scan).

**Logos**
15. `img.brandmark` and every `img.pressmark` have a real `src` and a real `alt`.
16. Every lockup carries a **literal `fill`**. Any `currentColor`, `fill="inherit"`
    or CSS-driven colour must be rewritten before injection — an `<img>` SVG cannot
    inherit host colour and will render black.
17. On dark boards (01, 04, 05, 06, 08): every logo is a light/reversed version.
    Sample mean luminance; reject below `0.45`.
18. On light boards (02, 03, 07): reject logos above `0.55` mean luminance.
19. Logo artwork trimmed to its ink, and fully inside its own `viewBox` — artwork
    overflowing the viewBox clips before CSS applies and `object-fit` cannot fix it.

**Integrity**
20. Fonts resolved (`document.fonts.ready`) and the Google Fonts `<link>`
    actually loaded. A fallback serif invalidates every measurement above.
21. No `animation`, `transition`, `@keyframes`, `:hover`, `:focus` introduced.
22. Still exactly seven `:root` colour variables; no hard-coded hex added.
23. Tile captions present and uppercase.
24. `#board[data-variant]` matches the variant of the file actually used.

**Judgement**
25. Reading order is hero → headline → subline → metrics → copy. If copy reads
    first, the headline is too small for its content or the hero is too weak.

---

## PART 5 — FILES

```

REVIEW.md                 review of 17 engine-generated boards — read alongside this
SPEC-v2.md                this document — structure and copy
IMAGERY.md                image sourcing and generation — mandatory
assets/*.jpg              5 neutral tone placeholders (assets/README.txt)
assets/logos/             50 files — two complete ink sets:
                            press-01..24.svg      dark ink,  light boards 02/03/07
                            press-01..24-rev.svg  light ink, dark boards 01/04/05/06/08
                            brand-mark.svg / brand-mark-rev.svg
Board System v2.dc.html   all 24 previewed with notes
build/kit2.js             generator — not part of the deliverable
build/counts.html         fit + count-tolerance harness — not part of the deliverable
build/geom.html           geometry probe — not part of the deliverable
```
