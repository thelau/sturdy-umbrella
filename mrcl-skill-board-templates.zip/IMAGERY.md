# IMAGERY — sourcing and generation rules

Binding companion to `SPEC-v2.md`. The layouts are solved; **image quality is now
the only variable that decides whether a board reads as real work or as a draft.**

This is not a theory. Across 17 engine-generated boards reviewed in `REVIEW.md`,
the ones that read as real award submissions and the ones that read as drafts used
**the same layouts**. The only difference was that some carried real execution
photography and some carried flat colour gradients. Nothing else in this document
matters as much as that.
On an award board the image is 60–100% of the surface. A perfect layout carrying a
mediocre image is a mediocre board.

Order of preference, always:

1. **Real campaign assets** — stills, film frames, product shots, screenshots
2. **Real assets, recomposed** — crop, extend, retouch a real asset to fit the box
3. **Generated imagery** — only when 1 and 2 are impossible, and only to this spec
4. **Nothing** — an honest empty state beats a bad generation; drop to `--lean`

Never mix registers on one board. A generated hero above real execution tiles
reads as a fake, and juries see it instantly.

---

## PART 1 — TECHNICAL FLOOR

Non-negotiable for every image on every board.

| Property | Requirement |
|---|---|
| Hero, full-bleed boards | ≥ `2880 × 1620` native (1.5× the 1920×1080 box) |
| Hero, 04 (band) | ≥ `2880 × 940` |
| Hero, 07 (cell) | ≥ `1600 × 690` |
| Hero, 08 (per side) | ≥ `1440 × 1620` each — **portrait 4:5, not landscape** |
| Execution tile | ≥ `1150 × 647` — **16:9**, every slot on every variant |
| Format | JPEG q82–90 for photography; PNG only for UI screenshots and logos |
| Colour | sRGB, embedded profile stripped |
| Upscaling | none. Never upscale to hit a floor — recompose or pick another board |
| Compression | no visible blocking in flat gradients or shadow; check skies and walls |
| Aspect | match the box aspect; the board **crops centre**, it does not letterbox |

Aspect ratios by box, so nothing important is cropped away:

| Box | Aspect | Generate at |
|---|---|---|
| Full-bleed hero (01, 02, 03, 05, 06) | 16:9 | `2880 × 1620` |
| 04 hero band | ~3:1 | `2880 × 940` |
| 07 hero cell | ~7:3 | `2240 × 960` |
| 08 hero A / B | 4:5 | `1440 × 1800` each |
| Execution tile | **16:9** | `1150 × 647` (base 380 × 214 slot at 3×) |
| 07 feature cell | ~10:3 | `1520 × 460` |

---

## PART 2 — THE CLEAR ZONE

Every board carries type directly on its hero. Each has a region the image **must
leave quiet** — low contrast, low detail, no faces, no text, no hard edges.

| Board | Clear zone (board px) | What sits there |
|---|---|---|
| **01** | `x 127–1794, y 280–490` centre band | headline 150px + subline |
| | plus `y 0–100` and `y 660–1080` | brand, wall, copy, metrics, tiles |
| **02** | everything **outside** `x 420–1500, y 200–840` | headline, flanks, metrics, wall, tiles — **no scrim** |
| **03** | everything **outside** `x 400–1520, y 230–930` | headline, callouts, metrics, wall, tiles — **no scrim** |
| **04** | `y 730–910` (bottom 180px of the band) | 66px metric row, reversed |
| **05** | `x 0–700` full height | headline, subline, all copy, metrics |
| **06** | `x 0–442` and `x 1478–1920`, `y 280–880` | flanking copy |
| | plus `y 100–250` | headline crossing the frame |
| **07** | none — the hero is a bordered cell, no type on it | — |
| **08** | `y 100–290` across both halves, `y 700–1080` | headline, subline, copy, metrics |

The clear zone is a **composition instruction**, not a post-process. Darkening a
busy area in software produces the muddy grey patch that makes AI boards
recognisable. Compose so the quiet area is quiet in the photograph.

01, 05, 06 and 08 apply a veil; 02, 03 and 07 apply **none**. On those three the
image must be clean enough to carry small type unaided.

---

## PART 3 — GENERATION RULES

Only when no real asset exists. A generated image must be indistinguishable from
commercial photography at 1:1 on a 1920px board.

### Always specify

Every prompt names all six, or the result will look generic:

1. **Medium and format** — "editorial photograph", "documentary still",
   "product photograph on seamless ground", "film frame". Never "digital art",
   "illustration", "render", "4k", "8k", "trending", "masterpiece".
2. **Lens and distance** — "35mm, waist-up", "85mm portrait, shallow depth",
   "24mm wide, full environment". This controls composition more than any adjective.
3. **Light, named** — "overcast north light", "hard low sun, long shadows",
   "single softbox from camera left, falloff to black", "practical neon, mixed
   temperature". Vague light is the main tell of a generated image.
4. **The clear zone, explicitly** — "upper third is open sky, no detail",
   "seamless pale ground with 400px clear either side of the object",
   "subject centred, background falls to shadow at both edges".
5. **Palette** — 2–3 colours, tied to the board's `--color-primary` and
   `--color-accent`. Do not let the model choose.
6. **Aspect and pixels** — from the table in Part 1.

### Always negate

```
no text, no lettering, no signage, no watermark, no logo,
no visible brand marks, no captions, no UI chrome,
no extra fingers, no malformed hands, no duplicated limbs,
no plastic skin, no HDR halo, no oversharpening,
no fake bokeh, no vignette, no lens flare,
no collage, no border, no frame, no split panels
```

Text is the critical one. **Any legible generated text disqualifies the image** —
it will be wrong, and a jury will read it.

### Never generate

- **Any logo, wordmark or brand mark.** These come from the brand as real SVG/PNG.
  A generated logo is a legal and credibility failure.
- **Any UI, app screen or dashboard.** Use a real screenshot, or build the UI in
  HTML and screenshot that. Generated interfaces contain nonsense text and
  impossible controls.
- **Any real, named person**, living or dead.
- **Any press masthead or publication logo.**
- **Any chart, graph or data visualisation.** Build it, don't generate it.
- **Any award show, festival or jury branding.**

### Per-board prompt recipes

Fill the brackets. Keep the structure.

**01 Centred Monument** — `2880 × 1620`, dark, tonal range needed
> Editorial photograph, 24mm wide. [SUBJECT] in [ENVIRONMENT]. Hard low sun from
> camera right, long shadows, deep shadow detail retained. Subject occupies the
> lower-middle third; the upper third is open [SKY / CEILING / WALL] with no
> detail. Muted palette of [COLOUR A] and [COLOUR B] with a single warm accent.
> Cinematic, unretouched, no text.

**02 Hero Object** — `2880 × 1620`, light, **no scrim**
> Product photograph. [OBJECT] centred on a seamless [PALE COLOUR] ground, single
> large softbox from above and slightly left, soft falloff, one gentle contact
> shadow. Object occupies the central third only; at least 400px of clean empty
> ground on both left and right and 200px above. Even, bright, no gradient
> banding. Commercial catalogue quality, no text, no props.

**03 Device Frame** — `2880 × 1620`, white, **no scrim**
> Photograph of [DEVICE] held / standing centred, screen facing camera and legible,
> 50mm, f5.6, shallow but readable depth. Pale [COLOUR] out-of-focus ground.
> Even diffuse light, no reflections on the screen. Clean margin of at least 400px
> either side of the device. **Composite the real UI screenshot into the screen
> afterwards — do not generate the interface.**

**04 The Logo Wall** — `2880 × 940`, navy, hero band
> Documentary photograph, 35mm. [SUBJECT / MOMENT] in [PLACE]. Available light,
> evening, cool shadows with a warm practical accent. Wide horizontal composition,
> subject centred and no taller than two thirds of frame; the bottom fifth is
> quiet ground or floor with no detail. Photojournalistic, slight grain, no text.

**05 The Left Rail** — `2880 × 1620`, dark, weight right
> Editorial photograph, 35mm. [SUBJECT] positioned in the **right two thirds** of
> frame. The left third falls away into shadow and empty space with no detail.
> Directional light from the right, deep blacks. Palette of [COLOUR A] and
> [COLOUR B]. Cinematic, no text.

**06 The Figure Board** — `2880 × 1620`, dark, radial veil
> Full-length environmental portrait, 50mm, subject centred, head and feet both
> inside frame, head no higher than the upper quarter. [PERSON DESCRIPTION —
> non-identifiable] in [ENVIRONMENT]. Single soft source from the front, the
> background falling to shadow at both left and right edges. Direct gaze. Natural
> skin, visible texture, no retouching, no text.

**07 The Evidence Grid** — hero `2240 × 960`, tiles `1520 × 460`, light
> Photograph of [ARTEFACT / EXECUTION] on a pale neutral ground, flat even light,
> straight-on or slight overhead angle, minimal shadow. Consistent framing and
> ground colour across the whole set. Catalogue documentation, no text.
>
> Generate all cells **in one batch with one prompt skeleton** — the grid only
> works if light, ground and framing match across every cell.

**08 The Sequence** — `1440 × 1800` **per side**, navy, two images
> Documentary photograph, 35mm, **portrait 4:5**. [SCENE] — [STATE A: before].
> Overcast flat light, desaturated, cool. Subject centred, full height, lower
> two thirds of frame; the top quarter is quiet.
>
> Then, for B: **the identical prompt with only the state changed** — same lens,
> same distance, same light, same framing, same palette. Change nothing else. If
> the two frames differ in exposure or colour temperature, regenerate rather than
> correct them in post.

**Execution tiles (all boards)** — **16:9**, `1150 × 647` minimum
> Photograph of [EXECUTION — OOH site / film still / retail moment / event / app
> screen / platform UI] in situ, 16:9 crop, subject centred with clear space at the
> bottom for a caption. Consistent light and palette with the hero image.

Every execution slot in the system is 16:9, so a correctly-shaped asset is not
cropped at all. Interface assets — app screens, dashboards, web experiences — belong
here: at 425 × 239 (lean) or 380 × 214 (base) a cropped UI region reads, though 8pt
body text inside a screenshot will not. Crop to the meaningful part: a header, a key
control, a chart, a hero state.

**Two execution assets is the minimum.** With 0 or 1, the strip is removed entirely
rather than run short — a lone slot in a strip built for several reads as a gap.

**A flat colour field is not an execution asset.** Not a gradient, not a tone field,
not a blurred colour wash, not a duplicate of the hero at lower opacity. The five
`assets/*.jpg` files exist to test a layout before real assets arrive; a board
carrying them is a layout test and must be tagged as one. Eight of the 17 reviewed
boards shipped with gradient tiles and all eight read as unfinished.

**Legibility floor: 300px.** A tile carrying a screen, UI, poster, artefact or
newspaper front page must render at least 300px wide. Below that nobody can tell
what the execution was, and the tile is decoration standing where evidence should be.
One reviewed board ran six real, well-shot executions at ~100px each — the assets
were good and the board still failed, because the work was illegible. If the
executions are screens, use `--lean` (425px slots) or base (380px), not `--loaded`
(236px) or board 04 (126px).

**Caption the deliverable, not the channel.** `IN-APP TRACKER`, `EARNED MEDIA`,
`POLICY PILOT`, `WELFARE DASHBOARD` tell a jury what was made. `DIGITAL` and
`SOCIAL` tell them nothing. Use the generic channel only when the specific is
genuinely unknown.

---

## PART 4 — REJECTION GATES

Reject and regenerate — do not patch — if any of these are true.

**Hard fail**
1. Any legible text, lettering, signage or watermark.
2. Any logo or brand mark.
3. Malformed anatomy: hands, fingers, teeth, eyes, limb count.
4. Nonsense structure: impossible architecture, floating objects, mismatched
   reflections or shadow directions.
5. Below the resolution floor, or upscaled to reach it.
6. The clear zone is not clear.
7. Visible generation artefacts: repeating texture, smeared edges, warped
   background lines.

**Quality fail**
8. Plastic or waxy skin; airbrushed pores.
9. HDR halo, crushed blacks, blown highlights.
10. Symmetrical centred composition where the board asked for weight left or right.
11. Colour palette not the one requested.
12. Depth of field that is physically impossible for the stated lens.
13. Light with no identifiable source, or shadows in conflicting directions.

**Placeholder fail** — the defining flaw of the first engine build
19. A flat colour field, two-stop gradient, tone wash or blurred colour plane in any
    execution slot. Automated test: standard deviation of luminance below `0.06`
    across the rendered tile, or fewer than 12 distinct quantised colours → fail.
20. Any `assets/*.jpg` tone placeholder surviving into output.
21. A tile that is the hero image repeated, recoloured or blurred.
22. An execution tile carrying a screen, UI, poster or artefact rendering under
    300px wide.

**Set fail** — checked across the whole board, not per image
14. Tiles that don't share light, ground and palette with each other.
15. Tiles that don't share light and palette with the hero.
16. On 08: heroes differing in exposure, temperature, lens or framing.
17. On 07: cells with different ground colours or camera angles.
18. A generated hero above real execution tiles, or the reverse.

**Automated pre-flight** — cheap and worth wiring in
- OCR the image; any detected word ≥ 3 characters → hard fail 1.
- Sample mean luminance and standard deviation inside the clear zone; high σ → the
  zone is busy → fail 6.
- Sample the four corners of every tile in a set; ground colour ΔE > 10 between
  tiles → fail 14.
- Check native dimensions against the Part 1 floor → fail 5.

---

## PART 5 — WHEN THERE IS NO IMAGE

For internal drafts, the board must still be honest about what's missing.

**Do** use the neutral placeholders in `assets/` — five flat or softly textured
tone fields, content-free by design:

| File | Use on |
|---|---|
| `dark-charcoal.jpg` | 01, 05, 06 |
| `deep-navy.jpg` | 04, 08 |
| `light-white.jpg` | 02, 03, 07 |
| `warm-amber.jpg` | any — textured warm |
| `neutral-landscape.jpg` | any — textured neutral |

`clinical-white.jpg` was deleted: it was a garbled mock board with fake headlines.
Nothing like it should ever enter the asset pool — a placeholder must be
**content-free**, never a picture of another board.

**Do** drop to `--lean` when there are fewer than 3 usable execution images. Three
real tiles beat eight filled with noise.

**Do** mark drafts. A board built on placeholders is a layout test, not a
submission; the engine should tag it as such in its output metadata so nobody
circulates it by accident.

**Don't** fill an empty tile with a colour block, a gradient, a pattern, a stock
photo of an unrelated subject, or a duplicate of the hero. Delete the tile and
change variant.

**Don't** run a strip with a single slot. Two is the minimum: below that, delete
`.strip` and let the board reflow. One asset stretched into a zone built for several
reads as a gap, however good the asset is.

**Don't** stretch, letterbox or pillarbox to fill a box. All boxes crop centre;
give them the right aspect from the start.

---

## PART 6 — LOGOS

Logos are **never** generated. They are real files, and they are the fastest way a
board is spotted as fake.

**The brand logo is an image, not type.** All 17 reviewed boards set the brand as a
type wordmark — `KNORR`, `SONY`, `GRAB`, `NIKE`, `Heineken`, `Coca-Cola` — rendered
in the board's headline face. It passes every bounds check and fails immediately in
front of anyone who knows the brand, because a brand's wordmark has specific
letterforms, spacing and proportion that a substituted typeface does not reproduce.
`img.brandmark` takes a real lockup. So does `img.pressmark`.

The one legitimate text treatment is a **deliberate** one: a ranged serif column at
40px reading as an editorial list of outlets, which one reviewed board did well.
Twenty publication names at 11px pretending to be a logo wall is not that.

| | Requirement |
|---|---|
| Format | SVG preferred; PNG at ≥ 3× the display height with real transparency |
| Colour | **baked in as a literal `fill`** — never `currentColor` (see below) |
| Two sets | a dark-ink and a light-ink version of every mark |
| Brand mark | one per board, `img.brandmark`, rendered at 46–52px height |
| Press mark | `img.pressmark` at 19–23px height depending on board |
| Trim | cropped to the ink — internal padding breaks the wall's optical rhythm |
| Sizing | height from CSS, `width:auto`. **Never set width or height inline** — it distorts the aspect ratio |
| viewBox | must fully contain the artwork — see below |
| Alt text | the real publication or brand name, always |

### Contrast, and why there are two sets of every logo

**An SVG referenced through `<img src>` renders in an isolated document and cannot
see the host element's `color`.** `fill="currentColor"` therefore does *not*
inherit the board's text colour — it resolves to the SVG document's initial value,
which is black, on every board regardless of theme. No CSS on the `<img>` can
change this. Setting `color` on `.brandmark` or `.pressmark` does nothing.

Consequence: **colour must be baked into each asset.** That is why `assets/logos/`
ships two complete sets:

| Set | Ink | Referenced by |
|---|---|---|
| `assets/logos/press-NN.svg`, `brand-mark.svg` | `#14140f` dark | **light boards — 02, 03, 07** |
| `assets/logos/press-NN-rev.svg`, `brand-mark-rev.svg` | `#f4f2ec` light | **dark boards — 01, 04, 05, 06, 08** |
| `logos/**/[slug]--light.svg` | `#14140f` dark | **light boards** — the outlet library |
| `logos/**/[slug]--dark.svg` | `#f4f2ec` light | **dark boards** — the outlet library |

The library's suffixes name the *background*, not the ink: `--dark.svg` is the variant
**for** dark boards, so the ink inside it is light. See `LOGOS.md`.

The engine must apply the same discipline to real logos:

- Dark boards — **01, 04, 05, 06, 08** — need light/reversed lockups with an
  explicit light `fill`. Sample mean luminance; reject below `0.45`.
- Light boards — **02, 03, 07** — need dark lockups. Reject above `0.55`.
- A lockup using `currentColor`, `fill="inherit"`, or a CSS class for its colour
  must be **rewritten with a literal `fill`** before injection. It will otherwise
  render black.
- No reversed version available → request one, or drop that outlet from the wall.
  Never place a dark logo on a dark board, and never add a white plate behind it.
- Producing both variants of one board (e.g. 01 dark and 03 light) means sourcing
  **both** ink versions of every logo used.

If logos are inlined as `<svg>` elements rather than `<img src>` they *would*
inherit `currentColor` — but the boards use `<img>` so that logos can be dropped
in as PNG or SVG interchangeably. Do not switch to inline SVG to dodge this rule;
two baked sets is the contract.

**Artwork must fit its own viewBox.** A supplied SVG whose glyphs or paths extend
past its `viewBox` clips *inside the SVG's own coordinate system* — before any CSS
applies. `object-fit:contain` cannot rescue it, and the result is a lockup with its
last letters sliced off. This is a common real-world input, especially from SVGs
exported with the text still live rather than outlined.

Pre-flight every supplied lockup:

- Render the SVG to a canvas at 4× and check for ink touching the right or bottom
  edge of the raster. Ink at the edge → clipped artwork → reject.
- Prefer lockups with **outlined text**. Live `<text>` also re-renders differently
  wherever the named font is missing, changing width unpredictably.
- If the artwork is otherwise good, fix it by widening the `viewBox` (and the
  `width`/`height` attributes with it) rather than scaling the artwork down.

**Text fallback.** Where no lockup exists, swap that one item for
`<span class="pressmark-text">Publication Name</span>`. The wall takes a mix. But
a wall that is mostly text is a text list — if more than about a third are
fallbacks, use `--lean` and show only the outlets you have artwork for.

**Optical sizing.** Logos are set to equal *height*, which makes wide wordmarks
look larger than compact ones. On a finished wall, reduce conspicuously wide marks
by 10–15% and raise very compact ones by the same, judged by eye. Equal height is
the starting point, not the answer.
