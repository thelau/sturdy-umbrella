# START HERE

Award board template system for marketing award show case study boards
(Cannes Lions, D&AD, Spikes Asia, Effies and equivalents).

You are receiving **8 base layouts × 4 content variants = 32 finished HTML
boards**. Your job is to inject real campaign content into them. **Do not
redesign them.** The geometry is measured, tested and fixed.

---

## Read in this order

1. **`START-HERE.md`** ← you are here. How to run the pipeline.
2. **`SPEC.md`** — structure and copy. Per-board measured geometry, slot boxes,
   what each board is for, how each one fails, and a 23-point QA gate.
3. **`IMAGERY.md`** — every image. Resolution floors, clear zones, per-board
   generation prompts, rejection gates, logo rules. **Not optional** — the layouts
   are solved, so image quality is the only remaining variable that decides whether
   output looks like real work or like a draft.
5. **`REVIEW.md`** — findings from 17 engine-generated boards, with the failure
   modes named per board. Read this before writing injection code.
4. **`LOGOS.md`** — the press and award logo library: 66 outlets and shows, two ink
   variants each. **Every file is a placeholder slot, not a logo** — read that
   document before wiring the press wall.

`index.html` opens an offline contact sheet of all 24 boards. Open it first to see
what you're working with.

---

## What's in the box

```
START-HERE.md          this file
SPEC.md                structure + copy contract, QA gate
IMAGERY.md             image sourcing + generation contract
index.html             offline contact sheet of all 24 boards
templates.json         machine-readable manifest of the same data

boards/                24 board files — 8 templates × 3 variants
  01-centred-monument.html          base
  01-centred-monument--lean.html    lean
  01-centred-monument--loaded.html  loaded
  …through 08-sequence

assets/
  *.jpg                5 neutral tone placeholders (see assets/README.txt)
  logos/               50 files — the board templates' own generic count slots

logos/                 press + award library, 66 entries × 2 ink variants
  press/               44 outlets   — [slug]--dark.svg / [slug]--light.svg
  awards/              22 shows     — same convention
  index.json           machine-readable manifest, all 66 entries
```

`logos/` is a **lookup by outlet**; `assets/logos/` is the generic count placeholders
inside the templates. Different jobs — don't conflate them.

Boards reference `../assets/…`, so **keep `boards/` and `assets/` as siblings**.

---

## The pipeline

### 1. Pick the board

From the campaign's **strongest asset**, not its category. Full matrix in
`SPEC.md` Part 3.

| Strongest asset | Board |
|---|---|
| One commanding environment or film frame | `01-centred-monument` |
| A product, pack or physical artefact | `02-hero-object` |
| A screen, app, device, AI demo | `03-device-frame` |
| Earned coverage (10+ real press logos) | `04-logo-wall` |
| A strong image *and* a dense argument | `05-left-rail` |
| One human subject, full height | `06-figure-board` |
| Many artefacts; breadth is the story | `07-evidence-grid` |
| A before/after or phased mechanic | `08-sequence` |

Two boards for one campaign: pair an image-led board (01, 02, 05, 06) with a
structure-led one (03, 04, 07, 08). Never two image-led boards.

### 2. Pick the variant — from assets, never from ambition

Every board declares its variant on `#board[data-variant]` (`lean` · `base` · `loaded`), so injection logic can detect the active execution zone without
parsing CSS.

| | Metrics | Press logos | Execution zone | Copy blocks |
|---|---|---|---|---|
| `--lean` | 3 | 8 | 3-slot tile strip | 3, one line each |
| base | 4 | 16 | 5-slot tile strip | 3 at 40 / 50 / 40 words |
| `--loaded` | 6 | 24 | 8-slot tile strip | 5 at full length |

Select the execution zone on **usable execution assets**:

| Usable execution assets | Variant | Execution zone |
|---|---|---|
| **0–1** | base or `--lean`, with `.strip` **removed** | none — the grid reflows cleanly, verified on all 8 boards |
| **2–3** | `--lean` | tile strip, 2 or 3 slots |
| 4–5 | base | tile strip, 4 or 5 slots |
| 6+ | `--loaded` | tile strip, 7 or 8 slots |

**Two execution images is the minimum.** Below that, delete `.strip` — a lone slot in
a zone built for several reads as a gap, however good the asset is.

**The strips are count-tolerant.** Each is `display:flex; justify-content:center` with
a fixed slot height, so it centres whatever count it is given and never leaves an
empty column. Lean holds 2 or 3, base 4 or 5, loaded 7 or 8. Delete the surplus
`.tile` elements; change nothing else.

Metrics and press gate independently: fewer than 3 metrics or fewer than 6 press
logos forces `--lean` whatever the execution count.

Supply execution imagery at **16:9** — every execution slot in the system is 16:9, so
a correctly-shaped asset is not cropped at all. A portrait or square asset still
crops, but to a normal frame rather than a sliver.

### 3. Inject

```html
<!-- hero -->
<div class="hero" style="background-image:url('data:image/jpeg;base64,…')">

<!-- execution tile: write the CUSTOM PROPERTY only -->
<div class="tile" style="--tile-img:url('data:image/jpeg;base64,…')">



<!-- logos: set src only, never width/height -->
<img class="brandmark" src="…" alt="Client Name">
<img class="pressmark" src="…" alt="Publication Name">

<!-- press fallback where no lockup exists; a wall may mix both -->
<span class="pressmark-text">Publication Name</span>
```

Text slots are plain text nodes: `.headline`, `.subline`, `.zone p`, `.lbl`,
`.m-n`, `.m-u`, `.tile-cap`, `.quote p`.

### 4. Capture

Viewport `1920 × 1080` → `scaleBoard()` resolves to `scale(1)` → 1:1 PNG.
Wait for `document.fonts.ready` **and** every `<img>` `decode()` before capture.
Nothing animates, so the first settled paint is the final frame.

### 5. Gate

Run all 23 checks in `SPEC.md` Part 4 plus the image gates in `IMAGERY.md`
Part 4. Any failure blocks the board.

---

## Read `REVIEW.md` first if you built the previous version

17 boards from the first engine build were reviewed. The finding that matters:
boards using **identical layouts** read as real award submissions or as drafts
purely according to whether their execution tiles held real photography or flat
colour gradients. Eight boards shipped with gradients. Fix that before anything
else in this document.

The other seven fixes, in order: never render `TBC` in a metric slot (delete the
slot); one `.tile-cap` per tile, not two; trim copy at a sentence boundary before
injection rather than letting the box clip it; run the dead-space and
descendant-bounds gates, which would have caught five boards mechanically; use
`logos/` for the brand and press instead of setting them as type; and check that
the hero actually depicts what the copy claims — one board illustrated a headphones
campaign with a water bottle.

## The five things that will bite you

**1. Tiles use a custom property, not `background-image`.**
`.tile` composites its own caption scrim over `--tile-img`. Writing
`background-image` on a `.tile` destroys the scrim and the caption becomes
illegible. This is the most common injection error.

**2. Logo colour is baked into the file, not applied by CSS.**
An SVG loaded through `<img src>` renders in an isolated document and **cannot**
inherit the host page's `color`. `fill="currentColor"` resolves to black on every
board. So `assets/logos/` ships two complete sets, and each board already
references the right one:

| Board | Logo set | Ink |
|---|---|---|
| 01, 04, 05, 06, 08 — dark | `press-NN-rev.svg`, `brand-mark-rev.svg` | `#f4f2ec` light |
| 02, 03, 07 — light | `press-NN.svg`, `brand-mark.svg` | `#14140f` dark |

The `logos/` library follows the same rule with the brief's own suffixes, which are
counter-intuitive: **`--dark.svg` means *for dark backgrounds*, so its ink is light.**

| File | Ink | Goes on |
|---|---|---|
| `[slug]--dark.svg` | light `#F4F2EC` | dark boards 01, 04, 05, 06, 08 |
| `[slug]--light.svg` | dark `#14140F` | light boards 02, 03, 07 |

Any supplied lockup using `currentColor`, `fill="inherit"` or a CSS class for its
colour must be **rewritten with a literal `fill`** before injection, or it renders
black. Details in `IMAGERY.md` Part 6 and `LOGOS.md`.

**3. Every board carries type directly on its hero.**
Each has a **clear zone** the image must leave quiet — full table in `IMAGERY.md`
Part 2. Boards **02, 03 and 07 apply no scrim at all**, so those heroes must be
clean enough to carry 12.5px type unaided. Compose the quiet area into the shot;
don't darken it afterwards, which produces the grey patch that makes AI boards
recognisable.

**4. The subline is mandatory and it is the slot most likely to be done badly.**
One sentence-case line, 8–14 words, explaining what the work actually *is*:

> ✅ The first delivery bag that makes riders visible at night
> ❌ A Bold New Campaign For A Bold New Brand
> ❌ Driving unprecedented engagement across the funnel

If you can't write it, the entry hasn't been understood well enough to build a
board yet.

**5. Cut copy, never shrink type.**
Body copy is 12.5px / 1.55 on every board. If content overflows, cut words. The
budgets are 40 / 50 / 40 (+ 40 / 40 on `--loaded`) and they are calibrated to the
boxes. Reducing type size is the fastest way to make a board look amateur.

---

## Never

- Redesign, re-space or re-scale a board. Change content, not layout.
- Add an eighth colour. Each board has exactly seven `:root` variables.
- Add animation, transition, `@keyframes`, `:hover` or `:focus`.
- Generate a logo, a UI screen, a chart, a masthead, or a named real person.
  (`IMAGERY.md` Part 3.)
- Leave a placeholder in output: no `[NUMBER]`, `[UNIT]`, `Brand Name`,
  `Publication`, `Campaign Headline`, or any `assets/` path.
- Fill an empty slot with a colour block, a gradient, or a duplicate of the hero.
  **Delete the element and change variant instead.**
- Inject a flat colour field, gradient, tone wash or blurred hero copy into any
  execution slot. If there is no real asset, delete the slot.
- Render `TBC`, `N/A`, `—` or `0` in a metric. Delete the metric.
- Set the brand or a press outlet as type where a logo belongs.
- Let a box clip copy or a headline. Cut words instead.
- Render a strip with a single slot. Two is the minimum — below that, delete `.strip`.
- Override `aspect-ratio` or the slot height on any execution slot.
- Upscale an image to reach a resolution floor. Recompose, or pick another board.

---

## Every execution slot is 16:9

This is the v3 fix. Earlier tile strips were 3:1, so a landscape interface asset
injected via `background-size:cover` lost most of its height — an app screenshot came
out as an unreadable letterbox sliver.

Now **every execution slot on every board and every variant is exactly 16:9**, set
with `aspect-ratio` so the slot derives its height from its column width:

| Variant | Slot size | Slots | At one fewer |
|---|---|---|---|
| `--lean` | 425 × 239 | 3 | centres at 2 |
| base | 380 × 214 | 5 | centres at 4 |
| `--loaded` | 236 × 133 | 8 | centres at 7 |

Board 04's strip sits inline beside the brand, so its slots are the smallest in the
system (126 × 71 at base); board 07 is a grid board whose strip runs inside its own
1832px gutter, with two further assets in the grid itself. Measured boxes for every
board and variant are in `templates.json`.

**Never override `aspect-ratio` or set an explicit height on a slot.** If a slot
measures anything other than 16:9, the rule has been overridden — restore it rather
than resizing.

## The logo library is stubbed — deliberately

`logos/` contains all 132 files the brief specifies, at the right names, sizes and ink
variants, with a complete `index.json`. **None of them is the real mark.** We did not
reconstruct the BBC, CNN, Reuters, Cannes Lions or D&AD identities from written
descriptions: they are registered brand identities, and an approximation of a mark a
jury recognises on sight reads as counterfeit and damages the board.

Each placeholder renders the outlet's **name**, so boards built on the library are
readable and reviewable while obviously not carrying fake logos. Replace each file
with the real licensed lockup — keeping the filename, `viewBox` and pixel dimensions
— and nothing in the templates changes. Sources are in `index.json`; the procedure
and QA gate are in `LOGOS.md`.

## Placeholder assets

The 5 JPGs in `assets/` are deliberately content-free tone fields — they exist so
a layout can be tested before real assets arrive. A board built on them is a
**layout test, not a submission**; tag it as such in your output metadata so
nobody circulates it by accident.

`assets/README.txt` records which placeholder suits which board, and one deleted
file worth knowing about: an earlier "clinical white" placeholder was a garbled
mock of another case-study board with fake headlines baked in. A placeholder must
be content-free. Never let an image of another board into the asset pool.
