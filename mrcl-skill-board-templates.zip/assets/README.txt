Placeholder imagery for the v2 board templates.

dark-charcoal.jpg    flat dark gradient      — dark boards
deep-navy.jpg        flat navy gradient      — dark boards
light-white.jpg      flat light gradient     — light boards
warm-amber.jpg       textured warm bokeh     — any
neutral-landscape.jpg textured neutral scene — any

clinical-white.jpg is NOT used: it is a garbled AI mock of a case-study board
(visible fake headlines) and must not appear on any output board.

logos/brand-mark.svg        brand lockup placeholder, ink #14140f   — light boards
logos/brand-mark-rev.svg    brand lockup placeholder, light #f4f2ec — dark boards
logos/press-01..24.svg      press mastheads, ink   — light boards 02, 03, 07
logos/press-01..24-rev.svg  press mastheads, light — dark boards 01, 04, 05, 06, 08

An SVG loaded through <img src> renders in isolation and CANNOT inherit the host
page's colour, so fill="currentColor" would come out black on every board. Every
asset here carries an explicit fill instead, which is why there are two sets.
The same applies to real logos: the dark boards need reversed/white artwork.