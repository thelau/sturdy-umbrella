# Engine output review — 17 boards

Reviewed against `SPEC.md` and `IMAGERY.md`. Sorted by what to fix first, and
separated into **engine bugs** (code), **spec gaps** (my fault — now fixed) and
**asset problems** (sourcing).

---

## The single biggest finding

Compare `board_a_every-trip-counts` and `board_b_every-trip-counts` (Grab), or
`board_b_share-a-coke-again` (Coca-Cola), against `board_01_centred_monument`
(Knorr) and `board_06_figure_board` (Dove).

The Grab and Coke boards look like real award submissions. The Knorr and Dove
boards look like drafts. **The layouts are the same. The difference is the
execution tiles are real photographs in one set and flat colour gradients in the
other.**

Everything else in this review is secondary to that. A board with six real
execution images and a text press list beats a board with a perfect press wall and
six grey rectangles, every time.

The three boards that got this right also share two other habits worth copying:
tiles at a size where you can *read* what the execution was (Grab's right-hand
rail, Coke's bottom strip), and captions that name a real deliverable —
`IN-APP TRACKER`, `EARNED MEDIA`, `POLICY PILOT` — rather than a generic channel.

---

## Engine bugs — fix in code

**1. Placeholder gradients are being injected as execution assets.**
Boards 01, 02, 03, 05, 06, 07, 08, 10 and both Dove/Knorr variants fill
`--tile-img` with flat two-stop gradients. These are the `assets/*.jpg` tone
placeholders, or generated equivalents. They are for layout testing only.
→ New gate: `IMAGERY.md` §4 rejection 19, and QA 11a in `SPEC.md`.

**2. `TBC` is being rendered into metric slots.**
`board_a_moderate-drinkers-wanted` and `board_b_moderate-drinkers-wanted` both show
three metrics reading `TBC`. This is worse than having no metrics — it advertises an
incomplete entry to a jury.
→ If a metric value is unknown, **delete that `.met` element**. If fewer than 2
remain, delete the whole metric row. Never `TBC`, `N/A`, `—`, `0`, or `Pending`.

**3. Duplicate tile captions.**
`board_04_logo_wall` renders every caption twice — `BROADCAST` above `BROADCAST`,
`OOH` above `OOH`, `DIGITAL` above `DIGITAL`. Each `.tile` must contain exactly one
`.tile-cap`.

**4. Copy is being truncated mid-sentence.**
`board_a_share-a-coke-again` and `board_b_share-a-coke-again`, What It Took: *"A
72-hour real-time content room amplifying organic sharing at"* — cut off. The copy
exceeded its box and was clipped rather than shortened.
→ Copy must be trimmed to budget **before** injection, at a sentence boundary. New
gate: every `.zone p` ends in terminal punctuation.

**5. The subline is colliding with the hero on board 03.**
`board_03_device_frame`: the subline renders across the phone at the wrong size in
the mono face, half-hidden behind the device. The board expects it in the
right-hand column beside the headline, not spanning the full width.

**6. Board 07's cells are unequal and the board is 40% empty.**
`board_07_evidence_grid` (IKEA): the two top cells have different heights, the third
asset floats centred below with a caption, and the bottom third of the board is bare.
Same failure on `board_b_moderate-drinkers-wanted`, which is empty below y≈960.
→ New hard gate: **no empty horizontal band taller than 120px**, and the lowest
painted element must reach within 60px of the board floor. See QA 2a.

**7. Headlines are clipping at the baseline.**
`board_02_hero_object`: "SILENCE IS POWER" is cut along the bottom of every glyph.
`board_a_moderate-drinkers-wanted`: the "Heineken" descender is clipped.
Display serifs at 88–120px need the line box to accommodate descenders.
→ `line-height` no lower than 1.05 on serif headlines, and never clip to fix a
too-long headline — cut words.

**8. Board 02's metrics are cut off at the right board edge.**
`41%` reads as `4|1%`, `94%` as `9|4%`. The metric column is overflowing the board
box. The bounds test should have caught this — it suggests the QA gate isn't being
run, or is only checking `#board` dimensions rather than descendants.

---

## Spec gaps — my fault, now fixed

**9. I never said a gradient isn't an asset.**
`IMAGERY.md` said "supply execution assets at 16:9" and listed resolution floors,
but never stated that a flat colour field fails. Now an explicit rejection gate with
an automated test (luminance σ inside the tile).

**10. I specified the tile strip's slot count but not its zone width.**
On 01, 05, 06 and 08 the 3-tile strip centres inside a 1920px zone, leaving large
empty flanks that read as missing content — visible on Knorr, Dove, Grab-a and
Foodpanda. The strip is `justify-content:center`, which was the fix for count
tolerance, but the zone needs to shrink with the count.
→ Now: at 2–3 slots the zone is capped at 1280 and the flanks carry the board
background *deliberately*, or the slots scale up to fill. Documented per board.

**11. I never gave the brand logo the same force as the press logos.**
Every one of the 17 boards sets the brand as a **type wordmark** — `KNORR`, `SONY`,
`GRAB`, `NIKE`, `Heineken`, `Coca-Cola`. `SPEC.md` said `img.brandmark` takes a real
lockup, but the engine is substituting text and nothing failed.
→ Now a hard gate: `img.brandmark` must be an `<img>` with a real `src`. A text
node in its place fails. Same for `img.pressmark`.

**12. I never set a floor on tile size relative to what's in the tile.**
Coke-b's six tiles are ~100px wide at the foot — the executions are unreadable.
Grab-b's are 380px and legible. Both are "within spec".
→ Now: an execution tile carrying a screen, UI, poster or artefact must be at least
300px wide in the rendered board. Below that, use fewer, larger tiles.

---

## Asset problems — sourcing

**13. Two boards show assets from the wrong campaign entirely.**
`board_02_hero_object` (Sony) is a headphones campaign illustrated with a **frosted
water bottle**. `board_03_device_frame` (GovTech Singapore, national digital
identity) shows a **retail banking app** with Amazon and Spotify transactions.
→ These would end a jury's engagement instantly. New gate: the hero must depict the
subject the copy names. Not automatable — needs a model or human check comparing
`.subline` against the hero. Added as QA 23.

**14. Press walls are text on 15 of 17 boards.**
The `logos/` library exists for this. Coke-b is the one that makes text work — a
serif column, ranged, at 40px, treated as a deliberate typographic list rather than
a fallback. That's a legitimate pattern; the default should still be logos.

**15. Nike's press list runs to 20+ names across two rows.**
`board_09` / `board_10`: a text wall. With that many outlets, logos are mandatory —
20 names in 11px type is noise, 20 logos is a credential.

---

## What worked — replicate this

- **`board_b_every-trip-counts` (Grab)** is the strongest board of the 17. Real
  tiles at a legible size in a right-hand rail, deliberate captions, one metric row,
  brand at the foot. Nothing decorative.
- **`board_a_every-trip-counts` (Grab, white)** — the six-tile band with real
  photography, and the `OOH` tile showing an actual billboard with the live fund
  counter on it. That's evidence, not illustration.
- **`board_b_share-a-coke-again`** — press as a ranged serif column is a genuinely
  good pattern. The navy ground with the warm street photography works.
- **`board_10_left_rail_loaded` (Foodpanda)** — five copy blocks and six metrics
  holding cleanly on a full-bleed hero, with the subject positioned right of centre
  exactly as board 05 asks. The best use of the loaded variant.
- **`board_09_monument_loaded` (Nike)** — 5 blocks + 6 metrics proving the loaded
  variant carries real density.

---

## Priority order

1. Stop injecting gradient placeholders (bug 1). Nothing else matters as much.
2. Never render `TBC` (bug 2), fix duplicate captions (bug 3), stop mid-sentence
   truncation (bug 4).
3. Run the dead-space gate (bug 6) and the descendant bounds test (bug 8) — both are
   mechanical and would have caught five of these boards.
4. Wire the `logos/` library for brand and press (gaps 11, 14, 15).
5. Add the hero-relevance check (asset 13).
