# LOGOS — press and award logo library

`logos/` holds a slot for every outlet and award show in the APAC brief: **66 entries
× 2 ink variants = 132 SVGs**, plus 16 square icon variants and `index.json`.

**Read this first: every file is a placeholder slot, not a logo.**

---

## Why placeholders and not recreations

The brief asked for the marks to be reconstructed from written descriptions — the BBC
News blocks, the CNN stencil, the Reuters sphere, the Cannes Lions seal, the D&AD
pencil. We have not done that, for two reasons.

1. **These are registered brand identities.** Rebuilding a distinctive mark from a
   description is still reproducing that brand's identity; calling the output a
   "design recreation" does not change what it is or who owns it. The brief's own
   legal note anticipates takedown requests, which is a signal that the approach
   carries risk rather than avoids it.
2. **An approximation is worse than no logo.** These marks are the most recognisable
   in the industry — a jury and every client in the room knows exactly what the Cannes
   Lions seal looks like. A near-miss version reads as counterfeit and undermines the
   credibility of the whole board, which is the opposite of what a press wall is for.

### "But they're publicly available"

They are downloadable; that is not the same as licensed. We checked the actual
sourcing routes:

- **Official channels are gated.** Cannes Lions publishes its press kits and logos
  through a Press Portal restricted to Festival-accredited media. Most award shows and
  publishers work the same way — accreditation, partnership, or a written request.
- **The freely downloadable copies are third-party mirrors** (seeklogo, brandlogos,
  logos-download, brandsoftheworld and similar). Their own terms say the logos remain
  the property of the owners and are offered for *personal use only*, displayed for
  identification, with the site explicitly not affiliated with or endorsed by the
  brand. Those terms do not cover an agency redistributing the file inside a client
  deliverable — which is exactly what this handoff is.

That leaves three legitimate routes, in order of preference:

1. **Accredited access.** Publicis holds press accreditation with most of these
   outlets and shows already. Request the media kit through it — it is the fastest
   route to a correct, current, licensed file.
2. **Ask.** Trade publishers routinely supply a lockup for coverage credit on request.
   A short email gets a licensed SVG and written permission in the same reply.
3. **Text fallback.** Where neither is available, use `span.pressmark-text`. A
   correctly set publication *name* is honest and looks deliberate; a wrong-shaped
   approximation of the logo does not.

Every entry in `index.json` carries a `website` to start from, and a `status` field to
track which route each asset came through.

---

## What the placeholders give you

The **system** is complete and correct, so the engine can be built and tested today:

- every filename, slug, directory and variant the brief specifies
- exact dimensions — `240 × 80` lockups, `80 × 80` squares, explicit `width`/`height`
- both ink variants, with colour **baked in** rather than inherited
- self-contained: no external `href`, no `<image>`, no linked fonts, no raster
- static: no `animation`, `transition`, `@keyframes`, `:hover`, no JavaScript
- `index.json` with all 66 entries and full metadata

Each placeholder renders the outlet's **name**, so a board built with placeholders is
readable and reviewable — you can see which outlet sits where — while being obviously
not the real mark.

---

## Ink variants: read this carefully

The brief's suffix names are counter-intuitive, so to be explicit:

| File | Ink | Goes on |
|---|---|---|
| `[slug]--dark.svg` | **light** `#F4F2EC` | **dark** boards — 01, 04, 05, 06, 08 |
| `[slug]--light.svg` | **dark** `#14140F` | **light** boards — 02, 03, 07 |

`--dark` means *for dark backgrounds*, so the ink inside it is light. The board
templates already route this way.

**Colour is baked into each file as a literal `fill`.** An SVG referenced through
`<img src>` renders in an isolated document and cannot inherit the host page's
`color`, so `fill="currentColor"` resolves to black on every board regardless of
theme. This is why two complete sets exist rather than one set plus CSS.

When you drop in a real lockup, apply the same rule: if the supplied SVG uses
`currentColor`, `fill="inherit"`, or a CSS class for its colour, **rewrite it with a
literal `fill`** before it goes near a board.

---

## Replacing a placeholder

1. Get the real SVG from the outlet's media kit or press page (`website` in
   `index.json`).
2. Produce two inks: light for `--dark.svg`, dark for `--light.svg`. Where the brand
   mark is a single colour, reverse it for the dark variant. Where it carries brand
   colour that reads on both — a red stencil, say — keep the colour and only remove
   any background fill.
3. **Keep the filename, `viewBox`, `width` and `height`.** Nothing in the board
   templates changes.
4. Outline all text (`font-to-path`). A live `<text>` element re-renders differently
   wherever the named font is missing, changing the mark's width unpredictably.
5. Trim the artwork to its ink. Internal padding breaks the press wall's optical
   rhythm, because the wall sizes marks by equal *height*.
6. Confirm the artwork fits inside its own `viewBox` — artwork that overflows clips
   before any CSS applies, and `object-fit` cannot rescue it.
7. Set `status` to `"licensed"` in `index.json` and record where the file came from.

---

## Per-file QA

- [ ] Opens in Chrome and Firefox with no font substitution warning
- [ ] Legible at `240 × 80`, and at `80 × 80` for squares
- [ ] No external dependency — no `href`, `xlink:href`, or `url()` to another file
- [ ] No `<image>` element
- [ ] `viewBox` **and** `width`/`height` set in pixels, never `100%`
- [ ] All text outlined — no live `<text>`
- [ ] `--dark` variant legible on `#0A0A0A`; mean luminance above `0.45`
- [ ] `--light` variant legible on `#FFFFFF`; mean luminance below `0.55`
- [ ] Under 50KB
- [ ] No `animation`, `transition`, `@keyframes`, `:hover`, or JavaScript
- [ ] Artwork inside its own `viewBox`, trimmed to the ink

Worth automating: luminance sampling, dimension check, a regex for external refs and
motion properties, and a 4× raster with an edge-ink test for viewBox overflow.

---

## Using the library on a board

Board press walls take one `img.pressmark` per outlet:

```html
<img class="pressmark" src="../logos/press/the-drum--dark.svg" alt="The Drum">
```

Height comes from CSS (19–23px depending on board) and width follows. **Never set
`width` or `height` inline** — it distorts the aspect ratio.

Where no lockup exists for an outlet, swap that one item for the text fallback; the
wall takes a mix:

```html
<span class="pressmark-text">Publication Name</span>
```

If more than about a third of a wall is text fallbacks, the wall is a text list —
use `--lean` and show only the outlets you have artwork for.

The generic `assets/logos/press-01..24.svg` files are unrelated: they are the count
placeholders inside the board templates themselves. This library is the lookup by
outlet.

---

## Priority order

Per the brief, highest board-usage first. All are stubbed; replace in this order.

**Priority 1** — Cannes Lions · D&AD Awards · Spikes Asia · Campaign Asia-Pacific ·
The Drum · WARC · Effie Awards · Clio Awards · The One Show · ADFEST

**Priority 2** — Ad Age · Adweek · Mumbrella · Campaign Brief ·
Marketing-Interactive · MAD STARS · APPIES APAC · AWARD Awards · Bloomberg ·
LBBOnline

**Priority 3** — the remaining 46 entries.

---

## One process note

The brief instructs "Do not scrape or download brand assets from live websites" and
then asks for the marks to be reconstructed from descriptions instead. Both routes
lead to the same place — an unlicensed asset — so neither is available to us. The
resolution is to license the real files through accreditation, which this library is
built to receive with no code change.

## Two corrections to the brief

- `advertising-vietnam` is listed twice in Section 1 (rows 14 and 45). There are
  **44 unique press outlets**, not 45.
- Section 2 is headed "21 shows" but lists **22 rows**.

44 + 22 = 66, so the stated total of 66 entries is right. Both notes are recorded in
`index.json` under `brief_discrepancies`.

---

## Destination

The brief names
`/context/publicis-groupe-apac--019f713d-3241-74e5-ae5f-a3f96204ffe2/logos/`.
This library ships at `logos/` inside the handoff so it travels with the boards that
consume it; copy the folder to that path as-is — the internal structure matches the
spec exactly.
